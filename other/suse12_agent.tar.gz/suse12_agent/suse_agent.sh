#!/bin/bash
#install Zabbix 3.0.X automatically.
# Tested on suse12
##############################################
# 变量
##############################################
err_echo(){
    echo -e "\033[41;37m[Error]: $1 \033[0m"
    exit 1
}
  
info_echo(){
    echo -e "\033[42;37m[Info]: $1 \033[0m"
}
  
warn_echo(){
    echo -e "\033[43;37m[Warning]: $1 \033[0m"
}
  
check_exit(){
    if [ $? -ne 0 ]; then
        err_echo "$1"
        exit1
    fi
}
   
##############################################
# check
##############################################
if [ $EUID -ne 0 ]; then
    err_echo "please run this script as root user."
    exit 1
fi
 

if [ "$(grep VERSION /etc/SuSE-release | awk '{if ( $3 >= 12  ) print "suse12"}')" != "suse12" ];then
    err_echo "This script is used for suse 12 only."
fi


# turn off the iptables                                                                                         
systemctl stop SuSEfirewall2.service
systemctl stop SuSEfirewall2_init.service

systemctl disable SuSEfirewall2.service
systemctl disable SuSEfirewall2_init.service

  
ZABBIX_CONFIG=/etc/zabbix/zabbix_agentd.conf

#{{{AgentInstall
function AgentInstall()
{
    groupadd zabbix
    useradd zabbix -g zabbix
    cp ./bin/zabbix_agentd /usr/sbin/zabbix-agentd
    chmod +x /usr/sbin/zabbix-agentd

    mkdir -p /etc/zabbix/
    cp -rf ./etc/* /etc/zabbix/

    cp init/zabbix-agentd.service /usr/lib/systemd/system/
    systemctl daemon-reload

}
#}}}
#{{{AgentConfig
function AgentConfig
{
    # 替换
	sed -i "s/Server=127.0.0.1/Server=${g_ZABBIX_SERVER_IP}/g" ${ZABBIX_CONFIG}
	sed -ri "s/(ServerActive=).*/\1${g_ZABBIX_SERVER_IP}/" ${ZABBIX_CONFIG}
	sed -i "s/^.*Hostname=.*$/Hostname=${g_ZABBIX_AGENT_HOSTNAME}/g" ${ZABBIX_CONFIG}
	sed -ri 's@(LogFile=).*@\1/var/log/zabbix/zabbix_agentd.log@' ${ZABBIX_CONFIG}
	sed -i 's/LogFileSize=0/LogFileSize=10/' ${ZABBIX_CONFIG}
    # 添加
    CHECK=`grep "EnableRemoteCommands=1"  ${ZABBIX_CONFIG} | wc -l `
    if [[ ${CHECK} == 0 ]]
    then
	    sed -ri '/EnableRemoteCommands=/a EnableRemoteCommands=1' ${ZABBIX_CONFIG}
    fi

    CHECK=`grep "^HostMetadata" ${ZABBIX_CONFIG} | wc -l `
    if [[ ${CHECK} == 0 ]]
    then
	    sed -ri "/HostMetadata=/a HostMetadata=${HostMetadata}" ${ZABBIX_CONFIG}
    fi

    # zabbix_agentd.conf.d
    CHECK=`grep "^Include=/etc/zabbix/zabbix_agentd.conf.d/" /etc/zabbix/zabbix_agentd.conf|wc -l`
    if [[ "w$CHECK" == "w0" ]]
    then
        mkdir -p /etc/zabbix/zabbix_agentd.conf.d/
        echo 'Include=/etc/zabbix/zabbix_agentd.conf.d/' >> /etc/zabbix/zabbix_agentd.conf
    fi

    # UnsafeUserParameters=1
    CHECK=`grep "^UnsafeUserParameters=1" /etc/zabbix/zabbix_agentd.conf|wc -l`
    if [[ "w$CHECK" == "w0" ]]
    then
        sed -ri '/UnsafeUserParameters=/a UnsafeUserParameters=1' /etc/zabbix/zabbix_agentd.conf
    fi

    # Timeout=10
    CHECK=`grep "^Timeout=3" /etc/zabbix/zabbix_agentd.conf|wc -l`
    if [[ "w$CHECK" == "w0" ]]
    then
        sed -ri '/Timeout=3/a Timeout=10' /etc/zabbix/zabbix_agentd.conf
    fi

    # AllowRoot=1
    CHECK=`grep "^AllowRoot=1" /etc/zabbix/zabbix_agentd.conf|wc -l`
    if [[ "w$CHECK" == "w0" ]]
    then
        sed -ri '/AllowRoot=0/a AllowRoot=1' /etc/zabbix/zabbix_agentd.conf
    fi

	mkdir -p /var/log/zabbix && chown -R zabbix:zabbix /var/log/zabbix/
	mkdir -p /var/run/zabbix && chown -R zabbix:zabbix /var/run/zabbix/
}
#}}}
#{{{AgentStart
function AgentStart
{
    systemctl start zabbix-agentd
    systemctl enable zabbix-agentd
}
#}}}
if [ $# != 3 ]
then
    echo usage: $0 "ServerIP" "hostname" "HostMetadata"
    echo eg: $0 "192.168.1.128" "ceshi_01" "Linux"
    exit
else
	g_ZABBIX_SERVER_IP=$1
	g_ZABBIX_AGENT_HOSTNAME=$2
    HostMetadata=$3
    AgentInstall
    AgentConfig
    AgentStart
fi
